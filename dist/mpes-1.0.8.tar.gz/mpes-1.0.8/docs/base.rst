Base classes  ``(mpes.base)``
===============================
Information about the base classes, the building blocks of data processing classes.

.. automodule:: mpes.base
   :members: