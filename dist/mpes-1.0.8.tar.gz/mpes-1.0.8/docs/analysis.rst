Analysis  ``(mpes.analysis)``
===============================
Data analysis pipeline including background removal, segmentation and fitting

.. automodule:: mpes.analysis
   :members:
