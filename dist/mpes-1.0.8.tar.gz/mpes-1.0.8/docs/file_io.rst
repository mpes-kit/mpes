File I/O & Processing  ``(mpes.fprocessing)``
===============================================
Custom methods to handle ARPES data I/O and standard data processing methods (filtering, dewarping, etc.)

.. automodule:: mpes.fprocessing
   :members: